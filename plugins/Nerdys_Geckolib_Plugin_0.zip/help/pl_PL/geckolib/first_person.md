Gdy ta opcja jest aktywna, wymienione poniżej grupy modeli zostaną zastąpione ramionami graczy.
Te ramiona będą renderowane na ekranie tylko w pierwszej osobie i nie będą częścią modelu.

